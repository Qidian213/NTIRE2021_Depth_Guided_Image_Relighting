runtime per image [s] : 0.033
CPU[1] / GPU[0] : 0
Extra Data [1] / No Extra Data [0] : 0
Other description : The Track2 test result of team DeepBlueAI
